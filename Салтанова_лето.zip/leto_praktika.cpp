﻿#include <iostream>
#include <fstream>
#include <windows.h> 
#include <math.h>
using namespace std;

int main()
{
	SetConsoleCP(1251); 
	SetConsoleOutputCP(1251); 

	ifstream F;
	int n;
	float sx=0, sy=0, syx=0, sx2=0, a, b, xyn, xn, yn, dx,dy,sy2=0,kor,sx3=0,sx4=0,syx2=0;
	F.open("experiment.txt");
	//Чтение исходных данных
	F >> n;
	//n- количество экспериментальных точек
	// x[n],y[n] – координаты экспериментальных точек

	int *x = new int[n];
	float *y = new float[n];

	cout << "X\n";
	for (int i = 0; i < n; i++)
	{
		F >> x[i];	cout << x[i] << " ";
	}
	cout << endl;
	cout << "Y\n";
	for (int i = 0; i < n; i++)
	{
		F >> y[i];	cout << y[i] << " ";
	}
	cout << endl;
	for (int i = 0; i < n; i++)
	{
		sx += x[i];
		sy += y[i];
		syx += y[i] * x[i];
		syx2 += y[i] * x[i] * x[i];
		sx2 += x[i] * x[i];
		sx3 += x[i] * x[i] * x[i];
		sx4 += x[i] * x[i] * x[i] * x[i];
		sy2 += y[i] * y[i];
	}

	//Расчёт коэффициентов линии регрессиии.
	b = (n * syx - sy * sx) / (n * sx2 - sx * sx);
	a = (sy - b * sx) / n;
	cout << "Уравнение линии регрессии y=" << b << "x + " << a<< endl;
	//Формирование массивов для изображения линии регрессии
	// на графике.

	float* x2 = new float[8];
	float* y2 = new float[8];

	for (int i=0;i<8;i++)
	{
		y2[i] = a + b * x[i];
	}

	//коэффициент корреляции

	xyn = syx / n;
	xn = sx / n;
	yn = sy / n;
	dx = sqrt(sx2 / n - pow(xn, 2));
	dy= sqrt(sy2 / n - pow(yn, 2));
	kor = (xyn-xn*yn) / dx*dy;
	cout << "Коффициент корреляции: " << kor << endl;

	// решение системы методом гаусса

	int m = 3;

	float d, s, /*a1[m + 1][m + 1],*/ c[4];

	float M[4][4] = { {0,0,0,0}, {0,8, sx, sx2},
						   {0, sx, sx2, sx3},
						   {0, sx2, sx3, sx4} };

	float B[4] = { 0, sy, syx, syx2 };

	for (int k = 1; k <= m; k++) // прямой ход
	{
		for (int j = k + 1; j <= m; j++)
		{
			d = M[j][k] / M[k][k]; 

			for (int i = k; i <= m; i++)
			{
				M[j][i] = M[j][i] - d * M[k][i]; 
			}
			B[j] = B[j] - d * B[k]; 
		}
	}

	for (int k = m; k >= 1; k--) // обратный ход
	{
		d = 0;
		for (int j = k + 1; j <= m; j++)
		{
			s = M[k][j] * c[j]; 
			d = d + s; 
		}
		c[k] = (B[k] - d) / M[k][k]; 
	}
	cout << "Корни системы: " << endl;

	float K = c[1], D = c[2], C = c[3];

	cout << endl << "K: " << K << " D: " << D << " K: " << C << endl;
	cout << endl << "Подобранная функциональная зависимость заданного вида: y = " << C << "*h^2 + " << D << "*h + " << K  << endl;

	float z[8];
	for (int i = 0; i < n; i++)
		z[i] = C*pow(x[i],2)+D*x[i]+K;


	F.close();

	ofstream f;
	f.open("result.txt");
	for (int i = 0; i < n; i++) {
		f << x[i] << " ";
		f << y2[i] << " ";
		f << z[i] << " ";
		f << y[i] << "\n";
	}
	f.close();
	
	return 0;
}

